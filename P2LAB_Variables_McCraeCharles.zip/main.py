# FIXME (1): Finish reading other items into variables, then output the four values on a single line separated by a space
user_int = int(input('Enter integer (32 - 126):\n'))
float = float(input('Enter float:\n'))
char = input('Enter character:\n')
str = input('Enter string:\n')
print(user_int,  float,  char,  str)
# FIXME (2): Output the four values in reverse
print(str, char, float, user_int)
# FIXME (3): Convert the integer to a characer, and output that character
con_char = chr(user_int)
print(user_int,'converted to a character is', con_char)